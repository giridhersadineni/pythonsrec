i=1
while(i<100):
    print(i)
    i=i+1
    if(i==50):
        break