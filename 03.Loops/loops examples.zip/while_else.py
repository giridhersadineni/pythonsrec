i=1
while(i<100):
    print(i)
    i=i+1
else:
    print(i)