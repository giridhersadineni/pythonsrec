for number in [1,2,3,4,5,6,7,8,8,99,7,56,56,45,345,3534,54,5465,546,456,456]:
    print(number)
else:
    print("end of list")