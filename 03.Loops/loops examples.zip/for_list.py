numbers=[1,2,3,4,6,4,3,5,6,7,8,923,3,54,67,89,7]
for number in numbers:
    print(number)



