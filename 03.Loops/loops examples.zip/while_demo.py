i=101   # initial condition  
while(i<=100):
    print(i)
    i=i+1  
else:
    print(i)
    print("Loop has ended")

