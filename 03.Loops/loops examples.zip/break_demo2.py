numbers=[1,2,3,4,6,4,3,5,0,7,8,923,3,0,67,0,7]
for number in numbers:
    
    if number==0:
        continue
    print(number)