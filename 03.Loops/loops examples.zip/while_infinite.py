i=1
while(True):
    print(i)
    i=i+1111111