numbers=[1,2,3,4,6,4,3,5,6,7,8,923,3,54,67,89,7]
i=0
list_length=len(numbers)
while(i<list_length):
    print(numbers[i])
    i=i+1
