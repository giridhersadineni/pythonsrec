for char in "Skillverse":
    print(char,end=" ")