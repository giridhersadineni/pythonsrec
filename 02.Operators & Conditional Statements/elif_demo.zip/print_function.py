from __future__ import print_function
a=int(input("Enter a Number"))
b=int(input("Enter another Number"))
c=a+b
print(c,"Is the sum")
#print c,"Is the sum"