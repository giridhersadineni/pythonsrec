messages=[
    # "Hi",
    # "Hello How are you doing",
    # "What are the plans for tomorrow"
]

if messages:
    print(messages)
else:
    print("No Messages")


