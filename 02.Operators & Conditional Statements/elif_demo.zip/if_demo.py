a=int(input("Enter a Number"))
b=int(input("Enter another Number"))
c=int(input("One more Please!!"))
if a>b:
    if a>c:
        print(a)
    else:
        print(c)
else:
    if (b>c):
        print(b)
    else:
        print(c)

    