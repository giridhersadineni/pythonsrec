a=int(input("Enter a Number"))
b=int(input("Enter another Number"))
if a>b: 
    print(a,"is the greatest number")
else:
    print(b,"is the greatest number")



   
read a number and store it in a    
read a number and store it in b
if a is bigger than b goto 14 else goto 15
print a is the biggest
print b is the biggest


