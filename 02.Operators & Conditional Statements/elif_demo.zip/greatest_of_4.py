a=int(input("Enter a Number"))
b=int(input("Enter another Number"))
c=int(input("One more Please!!"))
d=int(input("One more ! last One !!!! "))
max=a
if b>max: 
    max=b
if c>max:
    +


    max=c
if d>max:
    max=d
print(max,"is the Biggest Number")