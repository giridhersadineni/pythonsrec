in1=input("Enter a Number")
a=int(in1)
b=int(input("Enter another Number"))
if (a>b):
    print(a,"is the biggest number")
else:
    print(b,"is the biggest number")
